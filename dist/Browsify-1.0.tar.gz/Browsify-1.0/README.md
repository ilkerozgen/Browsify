# Browsify

## Installation

1. Clone the repository:

   > git clone https://github.com/ilkerozgen/Browsify.git

2. Navigate to the project directory:

    > cd Browsify

3. Install the application using the setup.py script:

    > python setup.py install

4. Run the application from command line:

    > browsify

## License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

